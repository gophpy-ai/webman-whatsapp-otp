<?php
return [
    'waba_token' => 'YOUR_WABA_TOKEN',
    'phone_number_id' => 'YOUR_PHONE_NUMBER_ID',
    'jwt_key' => 'YOUR_SECRET_KEY',
    'jwt_expire' => 3600,
];
