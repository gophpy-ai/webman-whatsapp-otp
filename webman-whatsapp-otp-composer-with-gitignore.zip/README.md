# Webman WhatsApp OTP Plugin

Install:
```
composer require yourname/webman-whatsapp-otp
```
